# receiver.py
import socket
import struct
import os

# --- Configuration ---
HOST = '0.0.0.0'  # Listen on all available network interfaces
PORT = 9027
BUFFER_SIZE = 65535  # Max UDP packet size
SAVE_DIR = "/app/received_images"

# --- In-memory buffer to store image chunks ---
# Format: { image_id: { 'total_pkts': int, 'chunks': { pkt_num: data } } }
images_buffer = {}

def main():
    if not os.path.exists(SAVE_DIR):
        os.makedirs(SAVE_DIR)
        print(f"Created directory: {SAVE_DIR}")

    # Create a UDP socket
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
        s.bind((HOST, PORT))
        print(f"[*] Listening on {HOST}:{PORT}")

        while True:
            try:
                # Receive packet from the client
                packet, addr = s.recvfrom(BUFFER_SIZE)

                # --- Packet Header Format (12 bytes) ---
                # image_id (4 bytes, signed int)
                # total_packets (4 bytes, signed int)
                # packet_number (4 bytes, signed int)
                header_format = "!iii"  # Network byte order, 3 signed integers
                header_size = struct.calcsize(header_format)
                
                if len(packet) < header_size:
                    print(f"Received a malformed packet from {addr}")
                    continue

                # Unpack the header
                header = packet[:header_size]
                data = packet[header_size:]
                image_id, total_packets, packet_number = struct.unpack(header_format, header)

                # Print progress
                if packet_number % 50 == 0: # Print every 50 packets to avoid spam
                    print(f"Received Pkt {packet_number + 1}/{total_packets} for ImageID {image_id} from {addr}")

                # Initialize buffer for a new image
                if image_id not in images_buffer:
                    images_buffer[image_id] = {
                        'total_pkts': total_packets,
                        'chunks': {},
                        'client_addr': addr
                    }

                # Store the chunk
                images_buffer[image_id]['chunks'][packet_number] = data

                # --- Check if the image is complete ---
                if len(images_buffer[image_id]['chunks']) == total_packets:
                    print(f"\n[+] All {total_packets} packets received for ImageID {image_id}!")
                    
                    # Reassemble the image in the correct order
                    full_image_data = b''.join(
                        images_buffer[image_id]['chunks'][i]
                        for i in range(total_packets)
                    )

                    # Save the image file
                    file_path = os.path.join(SAVE_DIR, f"received_image_{image_id}.jpg")
                    with open(file_path, "wb") as f:
                        f.write(full_image_data)
                    
                    print(f"[SUCCESS] Image saved to {file_path} ({len(full_image_data)} bytes)")
                    
                    # Clean up the buffer for this image
                    del images_buffer[image_id]
                    print("--------------------------------------------------\n")
                #print("Did not go into any if statements")
            except Exception as e:
                print(f"[ERROR] An error occurred: {e}")

if __name__ == "__main__":
    main()